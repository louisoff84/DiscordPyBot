# 🤖 Bot Discord Communauté Française

Un bot Discord complet développé en Python pour la gestion de communautés françaises. Le bot offre des outils d'administration essentiels, des commandes de divertissement et une gestion automatisée des membres.

## 🇫🇷 Fonctionnalités

### Commandes de Modération
- `/expulser` - Expulser un membre du serveur
- `/bannir` - Bannir un membre du serveur  
- `/debannir` - Débannir un utilisateur du serveur
- `/timeout` - Mettre un membre en timeout
- `/nettoyer` - Supprimer plusieurs messages

### Commandes Amusantes
- `/blague` - Obtenir une blague aléatoire
- `/fait` - Obtenir un fait amusant aléatoire
- `/de` - Lancer des dés
- `/piece` - Lancer une pièce (pile ou face)
- `/8ball` - Demander à la boule magique
- `/choisir` - Choisir parmi des options
- `/pfc` - Jouer à Pierre-Feuille-Ciseaux
- `/citation` - Obtenir une citation motivante

### Commandes Avancées
- `/sondage` - Créer un sondage interactif avec réactions
- `/rappel` - Programmer un rappel personnalisé
- `/meteo` - Simuler des informations météo
- `/profil` - Afficher le profil détaillé d'un utilisateur
- `/statistiques` - Statistiques complètes du serveur
- `/systeme` - Informations système du bot
- `/couleur` - Afficher une couleur avec ses codes

### Commandes d'Information
- `/aide` - Afficher toutes les commandes disponibles
- `/infoserveur` - Afficher les informations du serveur
- `/infoutilisateur` - Afficher les informations d'un utilisateur
- `/infobot` - Afficher les informations du bot
- `/ping` - Vérifier la latence du bot

### Fonctionnalités Automatisées
- Messages de bienvenue pour les nouveaux membres
- Logs d'arrivée/départ des membres
- Gestion d'erreurs complète
- Interface entièrement en français

## 🚀 Installation

1. Clonez ce repository
2. Installez les dépendances : `pip install discord.py psutil`
3. Configurez votre token Discord comme variable d'environnement `DISCORD_TOKEN`
4. Lancez le bot : `python main.py`

## ⚙️ Configuration

Modifiez `config.json` pour personnaliser :
- Nom et paramètres du bot
- Messages de bienvenue
- Contenu des commandes (blagues, faits)
- Couleurs des embeds

## 📋 Prérequis

- Python 3.8+
- discord.py
- psutil

## 🏗️ Architecture

```
bot/
├── commands/
│   ├── moderation.py    # Commandes de modération
│   ├── fun.py          # Commandes amusantes
│   └── info.py         # Commandes d'information
├── events/
│   └── member_events.py # Gestion des événements membres
├── utils/
│   └── helpers.py      # Fonctions utilitaires
└── bot.py              # Classe principale du bot
```

## 📝 Licence

Ce projet est open source et disponible sous licence MIT.