# Overview

A comprehensive Discord bot built with Python designed for community management. The bot provides essential server administration tools including moderation commands (kick, ban, timeout, message clearing), entertainment features (jokes, facts, games), and automated member management with welcome messages and logging. Built using discord.py with a modular architecture using Discord's slash command system.

# User Preferences

Preferred communication style: Simple, everyday language (French preferred).

# System Architecture

## Bot Architecture
- **Main Entry Point**: `main.py` serves as the application launcher with logging setup and token management
- **Core Bot Class**: `CommunityBot` extends discord.py's `commands.Bot` with custom configuration loading
- **Modular Design**: Commands organized into separate cogs (modules) for maintainability:
  - `ModerationCommands`: Server administration tools
  - `FunCommands`: Entertainment and interactive features  
  - `InfoCommands`: Information and utility commands
  - `MemberEvents`: Automated member management

## Command System
- **Slash Commands**: Uses Discord's modern app_commands system for better user experience
- **Permission Checking**: Custom decorators verify user permissions before command execution
- **Error Handling**: Comprehensive error handling with user-friendly feedback
- **Embed Responses**: Standardized rich embeds for consistent visual presentation

## Configuration Management
- **JSON Configuration**: `config.json` stores bot settings, welcome messages, and command content
- **Environment Variables**: Discord token stored securely in environment variables
- **Fallback System**: Default configuration provided when config file is missing or invalid

## Event Handling
- **Member Events**: Automatic welcome messages and join/leave logging
- **Intents System**: Configured with necessary Discord intents (message_content, members, guilds)
- **Async Processing**: Full asynchronous architecture for optimal performance

## Utility Functions
- **Time Parsing**: Flexible time string parsing for moderation commands
- **Embed Creation**: Standardized embed creation utilities
- **Helper Functions**: Common utility functions for formatting and validation

# External Dependencies

## Core Dependencies
- **discord.py**: Primary Discord API wrapper library
- **Python Standard Library**: asyncio, json, logging, pathlib, datetime, random, re, platform, os

## System Dependencies  
- **psutil**: System information gathering for bot stats
- **Python 3.8+**: Minimum runtime requirement

## Discord Integration
- **Discord Bot Token**: Required environment variable for authentication
- **Server Permissions**: Bot requires kick, ban, manage messages, and send messages permissions
- **Channel Configuration**: Optional welcome and log channels for automated features

## Runtime Environment
- **Environment Variables**: DISCORD_TOKEN for secure credential management
- **File System**: Logging to bot.log file, JSON configuration loading
- **Memory Storage**: In-memory configuration and state management (no persistent database)