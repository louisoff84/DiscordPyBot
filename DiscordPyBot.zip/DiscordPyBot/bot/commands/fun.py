import discord
from discord.ext import commands
from discord import app_commands
import random
import asyncio
from datetime import datetime

class FunCommands(commands.Cog):
    """Fun commands to entertain the community"""
    
    def __init__(self, bot):
        self.bot = bot
        self.config = bot.config
    
    @app_commands.command(name="blague", description="Obtenir une blague aléatoire")
    async def joke(self, interaction: discord.Interaction):
        """Envoie une blague aléatoire"""
        jokes = self.config.get('fun_commands', {}).get('jokes', [
            "Pourquoi les plongeurs plongent-ils toujours en arrière ? Parce que sinon, ils tombent dans le bateau !",
            "Que dit un escargot quand il croise une limace ? « Regarde le nudiste ! »",
            "Pourquoi les poissons n'aiment pas jouer au tennis ? Parce qu'ils ont peur du filet !"
        ])
        
        joke = random.choice(jokes)
        
        embed = discord.Embed(
            title="😄 Blague Aléatoire",
            description=joke,
            color=discord.Color.yellow(),
            timestamp=datetime.utcnow()
        )
        embed.set_footer(text=f"Demandé par {interaction.user.display_name}", icon_url=interaction.user.avatar.url if interaction.user.avatar else None)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="fait", description="Obtenir un fait amusant aléatoire")
    async def fact(self, interaction: discord.Interaction):
        """Envoie un fait amusant aléatoire"""
        facts = self.config.get('fun_commands', {}).get('facts', [
            "Le miel ne se périme jamais. Les archéologues ont trouvé du miel vieux de 3000 ans encore comestible !",
            "Un groupe de flamants roses s'appelle une 'flamboyance'.",
            "Les pieuvres ont trois cœurs et du sang bleu."
        ])
        
        fact = random.choice(facts)
        
        embed = discord.Embed(
            title="🧠 Fait Amusant",
            description=fact,
            color=discord.Color.blue(),
            timestamp=datetime.utcnow()
        )
        embed.set_footer(text=f"Demandé par {interaction.user.display_name}", icon_url=interaction.user.avatar.url if interaction.user.avatar else None)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="de", description="Lancer un dé")
    @app_commands.describe(sides="Nombre de faces du dé (défaut: 6)", count="Nombre de dés à lancer (défaut: 1)")
    async def roll(self, interaction: discord.Interaction, sides: int = 6, count: int = 1):
        """Lancer un ou plusieurs dés"""
        if sides < 2 or sides > 1000:
            await interaction.response.send_message("❌ Le nombre de faces doit être entre 2 et 1000 !", ephemeral=True)
            return
        
        if count < 1 or count > 20:
            await interaction.response.send_message("❌ Le nombre de dés doit être entre 1 et 20 !", ephemeral=True)
            return
        
        rolls = [random.randint(1, sides) for _ in range(count)]
        total = sum(rolls)
        
        embed = discord.Embed(
            title="🎲 Lancer de Dé",
            color=discord.Color.green(),
            timestamp=datetime.utcnow()
        )
        
        if count == 1:
            embed.description = f"Vous avez obtenu **{rolls[0]}** sur un dé à {sides} faces !"
        else:
            rolls_str = ", ".join(str(roll) for roll in rolls)
            embed.description = f"Vous avez obtenu : {rolls_str}\n**Total : {total}**"
            embed.add_field(name="Détails", value=f"{count}d{sides}", inline=True)
        
        embed.set_footer(text=f"Demandé par {interaction.user.display_name}", icon_url=interaction.user.avatar.url if interaction.user.avatar else None)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="piece", description="Lancer une pièce")
    async def coinflip(self, interaction: discord.Interaction):
        """Lancer une pièce"""
        result = random.choice(["Face", "Pile"])
        emoji = "🪙" if result == "Face" else "🔸"
        
        embed = discord.Embed(
            title=f"{emoji} Pile ou Face",
            description=f"La pièce est tombée sur **{result}** !",
            color=discord.Color.gold(),
            timestamp=datetime.utcnow()
        )
        embed.set_footer(text=f"Demandé par {interaction.user.display_name}", icon_url=interaction.user.avatar.url if interaction.user.avatar else None)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="8ball", description="Ask the magic 8-ball a question")
    @app_commands.describe(question="Your question for the magic 8-ball")
    async def eightball(self, interaction: discord.Interaction, question: str):
        """Ask the magic 8-ball a question"""
        responses = [
            "It is certain", "It is decidedly so", "Without a doubt",
            "Yes definitely", "You may rely on it", "As I see it, yes",
            "Most likely", "Outlook good", "Yes", "Signs point to yes",
            "Reply hazy, try again", "Ask again later", "Better not tell you now",
            "Cannot predict now", "Concentrate and ask again",
            "Don't count on it", "My reply is no", "My sources say no",
            "Outlook not so good", "Very doubtful"
        ]
        
        response = random.choice(responses)
        
        embed = discord.Embed(
            title="🎱 Magic 8-Ball",
            color=discord.Color.purple(),
            timestamp=datetime.utcnow()
        )
        embed.add_field(name="Question", value=question, inline=False)
        embed.add_field(name="Answer", value=f"*{response}*", inline=False)
        embed.set_footer(text=f"Asked by {interaction.user.display_name}", icon_url=interaction.user.avatar.url if interaction.user.avatar else None)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="choose", description="Choose randomly from a list of options")
    @app_commands.describe(options="Options separated by commas (e.g., option1, option2, option3)")
    async def choose(self, interaction: discord.Interaction, options: str):
        """Choose randomly from a list of options"""
        choices = [choice.strip() for choice in options.split(',') if choice.strip()]
        
        if len(choices) < 2:
            await interaction.response.send_message("❌ Please provide at least 2 options separated by commas!", ephemeral=True)
            return
        
        if len(choices) > 20:
            await interaction.response.send_message("❌ Please provide no more than 20 options!", ephemeral=True)
            return
        
        chosen = random.choice(choices)
        
        embed = discord.Embed(
            title="🤔 Random Choice",
            description=f"I choose: **{chosen}**",
            color=discord.Color.orange(),
            timestamp=datetime.utcnow()
        )
        embed.add_field(name="Options", value=", ".join(choices), inline=False)
        embed.set_footer(text=f"Requested by {interaction.user.display_name}", icon_url=interaction.user.avatar.url if interaction.user.avatar else None)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="rps", description="Play Rock, Paper, Scissors with the bot")
    @app_commands.describe(choice="Your choice: rock, paper, or scissors")
    async def rock_paper_scissors(self, interaction: discord.Interaction, choice: str):
        """Play Rock, Paper, Scissors with the bot"""
        choice = choice.lower().strip()
        valid_choices = ['rock', 'paper', 'scissors']
        
        if choice not in valid_choices:
            await interaction.response.send_message("❌ Please choose rock, paper, or scissors!", ephemeral=True)
            return
        
        bot_choice = random.choice(valid_choices)
        
        # Determine winner
        if choice == bot_choice:
            result = "It's a tie!"
            color = discord.Color.yellow()
        elif (choice == 'rock' and bot_choice == 'scissors') or \
             (choice == 'paper' and bot_choice == 'rock') or \
             (choice == 'scissors' and bot_choice == 'paper'):
            result = "You win! 🎉"
            color = discord.Color.green()
        else:
            result = "I win! 🤖"
            color = discord.Color.red()
        
        # Emojis for choices
        emojis = {'rock': '🪨', 'paper': '📄', 'scissors': '✂️'}
        
        embed = discord.Embed(
            title="🎮 Rock, Paper, Scissors",
            description=result,
            color=color,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name="Your choice", value=f"{emojis[choice]} {choice.title()}", inline=True)
        embed.add_field(name="My choice", value=f"{emojis[bot_choice]} {bot_choice.title()}", inline=True)
        embed.set_footer(text=f"Played by {interaction.user.display_name}", icon_url=interaction.user.avatar.url if interaction.user.avatar else None)
        
        await interaction.response.send_message(embed=embed)
