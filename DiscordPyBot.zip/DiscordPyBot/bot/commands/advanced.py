import discord
from discord import app_commands
from discord.ext import commands
import random
import asyncio
from datetime import datetime, timedelta
import json
import psutil
import platform

class AdvancedCommands(commands.Cog):
    """Commandes avancées pour le bot Discord"""
    
    def __init__(self, bot):
        self.bot = bot
        self.config = bot.config
        self.polls = {}  # Stockage des sondages actifs
        self.reminders = {}  # Stockage des rappels
    
    @app_commands.command(name="sondage", description="Créer un sondage avec réactions")
    @app_commands.describe(
        question="La question du sondage",
        options="Options séparées par des virgules (max 10)",
        duree="Durée en minutes (optionnel, défaut: 10)"
    )
    async def poll(self, interaction: discord.Interaction, question: str, options: str, duree: int = 10):
        """Créer un sondage interactif"""
        option_list = [opt.strip() for opt in options.split(',') if opt.strip()]
        
        if len(option_list) < 2:
            await interaction.response.send_message("❌ Au moins 2 options sont requises !", ephemeral=True)
            return
        
        if len(option_list) > 10:
            await interaction.response.send_message("❌ Maximum 10 options autorisées !", ephemeral=True)
            return
        
        if duree < 1 or duree > 1440:  # Max 24h
            await interaction.response.send_message("❌ Durée doit être entre 1 et 1440 minutes !", ephemeral=True)
            return
        
        # Émojis pour les réactions
        reaction_emojis = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
        
        embed = discord.Embed(
            title="📊 Sondage",
            description=f"**{question}**",
            color=discord.Color.blue(),
            timestamp=datetime.utcnow()
        )
        
        options_text = "\n".join([f"{reaction_emojis[i]} {option}" for i, option in enumerate(option_list)])
        embed.add_field(name="Options", value=options_text, inline=False)
        embed.add_field(name="Durée", value=f"{duree} minutes", inline=True)
        embed.set_footer(text=f"Créé par {interaction.user.display_name}")
        
        await interaction.response.send_message(embed=embed)
        message = await interaction.original_response()
        
        # Ajouter les réactions
        for i in range(len(option_list)):
            await message.add_reaction(reaction_emojis[i])
        
        # Stocker le sondage
        self.polls[message.id] = {
            'question': question,
            'options': option_list,
            'end_time': datetime.utcnow() + timedelta(minutes=duree),
            'channel': interaction.channel
        }
        
        # Programmer la fin du sondage
        await asyncio.sleep(duree * 60)
        await self.end_poll(message.id)
    
    async def end_poll(self, message_id):
        """Terminer un sondage et afficher les résultats"""
        if message_id not in self.polls:
            return
        
        poll_data = self.polls[message_id]
        try:
            message = await poll_data['channel'].fetch_message(message_id)
            
            results = {}
            reaction_emojis = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
            
            for i, option in enumerate(poll_data['options']):
                reaction = discord.utils.get(message.reactions, emoji=reaction_emojis[i])
                count = reaction.count - 1 if reaction else 0  # -1 pour exclure le bot
                results[option] = count
            
            # Créer l'embed des résultats
            embed = discord.Embed(
                title="📊 Résultats du Sondage",
                description=f"**{poll_data['question']}**",
                color=discord.Color.green(),
                timestamp=datetime.utcnow()
            )
            
            total_votes = sum(results.values())
            results_text = ""
            
            for option, count in results.items():
                percentage = (count / total_votes * 100) if total_votes > 0 else 0
                bar_length = int(percentage / 10)
                bar = "█" * bar_length + "░" * (10 - bar_length)
                results_text += f"{option}: {count} votes ({percentage:.1f}%)\n{bar}\n\n"
            
            embed.add_field(name="Résultats", value=results_text or "Aucun vote", inline=False)
            embed.add_field(name="Total des votes", value=str(total_votes), inline=True)
            
            await poll_data['channel'].send(embed=embed)
            
        except Exception as e:
            print(f"Erreur lors de la fin du sondage: {e}")
        
        # Nettoyer
        del self.polls[message_id]
    
    @app_commands.command(name="rappel", description="Programmer un rappel")
    @app_commands.describe(
        temps="Temps en minutes",
        message="Message du rappel"
    )
    async def reminder(self, interaction: discord.Interaction, temps: int, message: str):
        """Programmer un rappel"""
        if temps < 1 or temps > 10080:  # Max 1 semaine
            await interaction.response.send_message("❌ Le temps doit être entre 1 minute et 1 semaine (10080 minutes) !", ephemeral=True)
            return
        
        embed = discord.Embed(
            title="⏰ Rappel Programmé",
            description=f"Je vous rappellerai dans {temps} minute(s) : {message}",
            color=discord.Color.orange(),
            timestamp=datetime.utcnow()
        )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
        
        # Attendre et envoyer le rappel
        await asyncio.sleep(temps * 60)
        
        remind_embed = discord.Embed(
            title="⏰ Rappel !",
            description=message,
            color=discord.Color.red(),
            timestamp=datetime.utcnow()
        )
        remind_embed.set_footer(text=f"Rappel pour {interaction.user.display_name}")
        
        try:
            await interaction.followup.send(f"{interaction.user.mention}", embed=remind_embed)
        except:
            # Si le followup ne fonctionne pas, envoyer dans le canal
            await interaction.channel.send(f"{interaction.user.mention}", embed=remind_embed)
    
    @app_commands.command(name="meteo", description="Simuler des informations météo")
    @app_commands.describe(ville="Nom de la ville")
    async def weather(self, interaction: discord.Interaction, ville: str):
        """Simuler des informations météo (exemple)"""
        # Simulation de données météo
        conditions = ["Ensoleillé", "Nuageux", "Pluvieux", "Neigeux", "Orageux"]
        temperature = random.randint(-10, 35)
        condition = random.choice(conditions)
        humidite = random.randint(20, 90)
        vent = random.randint(0, 30)
        
        weather_emojis = {
            "Ensoleillé": "☀️",
            "Nuageux": "☁️",
            "Pluvieux": "🌧️",
            "Neigeux": "❄️",
            "Orageux": "⛈️"
        }
        
        embed = discord.Embed(
            title=f"{weather_emojis.get(condition, '🌤️')} Météo - {ville}",
            color=discord.Color.blue(),
            timestamp=datetime.utcnow()
        )
        
        embed.add_field(name="Température", value=f"{temperature}°C", inline=True)
        embed.add_field(name="Condition", value=condition, inline=True)
        embed.add_field(name="Humidité", value=f"{humidite}%", inline=True)
        embed.add_field(name="Vent", value=f"{vent} km/h", inline=True)
        
        embed.set_footer(text="⚠️ Données simulées à des fins de démonstration")
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="profil", description="Afficher le profil d'un utilisateur")
    @app_commands.describe(utilisateur="L'utilisateur dont afficher le profil")
    async def profile(self, interaction: discord.Interaction, utilisateur: discord.Member = None):
        """Afficher le profil détaillé d'un utilisateur"""
        user = utilisateur or interaction.user
        
        embed = discord.Embed(
            title=f"👤 Profil de {user.display_name}",
            color=user.color if user.color != discord.Color.default() else discord.Color.blue(),
            timestamp=datetime.utcnow()
        )
        
        embed.set_thumbnail(url=user.avatar.url if user.avatar else user.default_avatar.url)
        
        # Informations de base
        embed.add_field(name="Nom d'utilisateur", value=f"{user.name}#{user.discriminator}", inline=True)
        embed.add_field(name="ID", value=user.id, inline=True)
        embed.add_field(name="Surnom", value=user.display_name, inline=True)
        
        # Dates
        created_at = user.created_at.strftime("%d/%m/%Y à %H:%M")
        joined_at = user.joined_at.strftime("%d/%m/%Y à %H:%M") if user.joined_at else "Inconnu"
        
        embed.add_field(name="Compte créé le", value=created_at, inline=True)
        embed.add_field(name="A rejoint le serveur le", value=joined_at, inline=True)
        
        # Rôles
        roles = [role.mention for role in user.roles[1:]]  # Exclure @everyone
        roles_text = ", ".join(roles) if roles else "Aucun rôle"
        embed.add_field(name=f"Rôles ({len(roles)})", value=roles_text, inline=False)
        
        # Statut
        status_emoji = {
            discord.Status.online: "🟢 En ligne",
            discord.Status.idle: "🟠 Absent",
            discord.Status.dnd: "🔴 Ne pas déranger",
            discord.Status.offline: "⚫ Hors ligne"
        }
        embed.add_field(name="Statut", value=status_emoji.get(user.status, "❓ Inconnu"), inline=True)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="statistiques", description="Afficher les statistiques du serveur")
    async def stats(self, interaction: discord.Interaction):
        """Afficher les statistiques détaillées du serveur"""
        guild = interaction.guild
        
        embed = discord.Embed(
            title=f"📊 Statistiques - {guild.name}",
            color=discord.Color.purple(),
            timestamp=datetime.utcnow()
        )
        
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        
        # Membres
        total_members = guild.member_count
        online_members = sum(1 for member in guild.members if member.status != discord.Status.offline)
        bots = sum(1 for member in guild.members if member.bot)
        humans = total_members - bots
        
        embed.add_field(name="👥 Membres", value=f"Total: {total_members}\nEn ligne: {online_members}\nHumains: {humans}\nBots: {bots}", inline=True)
        
        # Canaux
        text_channels = len(guild.text_channels)
        voice_channels = len(guild.voice_channels)
        categories = len(guild.categories)
        
        embed.add_field(name="📝 Canaux", value=f"Texte: {text_channels}\nVocal: {voice_channels}\nCatégories: {categories}", inline=True)
        
        # Rôles et emojis
        embed.add_field(name="🎭 Autres", value=f"Rôles: {len(guild.roles)}\nEmojis: {len(guild.emojis)}\nBoosts: {guild.premium_subscription_count}", inline=True)
        
        # Propriétaire
        embed.add_field(name="👑 Propriétaire", value=guild.owner.mention if guild.owner else "Inconnu", inline=True)
        
        # Date de création
        created_at = guild.created_at.strftime("%d/%m/%Y")
        embed.add_field(name="📅 Créé le", value=created_at, inline=True)
        
        # Niveau de vérification
        verification_levels = {
            discord.VerificationLevel.none: "Aucune",
            discord.VerificationLevel.low: "Faible",
            discord.VerificationLevel.medium: "Moyenne",
            discord.VerificationLevel.high: "Élevée",
            discord.VerificationLevel.highest: "Très élevée"
        }
        embed.add_field(name="🔒 Vérification", value=verification_levels.get(guild.verification_level, "Inconnu"), inline=True)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="systeme", description="Afficher les informations système du bot")
    async def system_info(self, interaction: discord.Interaction):
        """Afficher les informations système du bot"""
        
        # Informations CPU
        cpu_percent = psutil.cpu_percent(interval=1)
        cpu_count = psutil.cpu_count()
        
        # Informations mémoire
        memory = psutil.virtual_memory()
        memory_percent = memory.percent
        memory_used = round(memory.used / 1024**3, 2)  # GB
        memory_total = round(memory.total / 1024**3, 2)  # GB
        
        # Informations disque
        disk = psutil.disk_usage('/')
        disk_percent = disk.percent
        disk_used = round(disk.used / 1024**3, 2)  # GB
        disk_total = round(disk.total / 1024**3, 2)  # GB
        
        embed = discord.Embed(
            title="🖥️ Informations Système",
            color=discord.Color.green(),
            timestamp=datetime.utcnow()
        )
        
        embed.add_field(
            name="💻 CPU",
            value=f"Utilisation: {cpu_percent}%\nCœurs: {cpu_count}",
            inline=True
        )
        
        embed.add_field(
            name="🧠 Mémoire",
            value=f"Utilisée: {memory_used}GB / {memory_total}GB\nPourcentage: {memory_percent}%",
            inline=True
        )
        
        embed.add_field(
            name="💾 Disque",
            value=f"Utilisé: {disk_used}GB / {disk_total}GB\nPourcentage: {disk_percent}%",
            inline=True
        )
        
        embed.add_field(
            name="🐍 Python",
            value=f"Version: {platform.python_version()}\nOS: {platform.system()} {platform.release()}",
            inline=True
        )
        
        embed.add_field(
            name="🤖 Bot",
            value=f"Serveurs: {len(self.bot.guilds)}\nLatence: {round(self.bot.latency * 1000)}ms",
            inline=True
        )
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="couleur", description="Afficher une couleur aléatoire ou spécifique")
    @app_commands.describe(hex_code="Code couleur hexadécimal (optionnel)")
    async def color(self, interaction: discord.Interaction, hex_code: str = None):
        """Afficher une couleur avec ses informations"""
        
        if hex_code:
            # Nettoyer le code hex
            hex_code = hex_code.replace('#', '').strip()
            if len(hex_code) != 6 or not all(c in '0123456789ABCDEFabcdef' for c in hex_code):
                await interaction.response.send_message("❌ Code couleur invalide ! Utilisez le format #RRGGBB", ephemeral=True)
                return
            color_int = int(hex_code, 16)
        else:
            # Couleur aléatoire
            color_int = random.randint(0, 0xFFFFFF)
            hex_code = f"{color_int:06X}"
        
        # Convertir en RGB
        r = (color_int >> 16) & 255
        g = (color_int >> 8) & 255
        b = color_int & 255
        
        embed = discord.Embed(
            title="🎨 Couleur",
            color=discord.Color(color_int),
            timestamp=datetime.utcnow()
        )
        
        embed.add_field(name="HEX", value=f"#{hex_code.upper()}", inline=True)
        embed.add_field(name="RGB", value=f"rgb({r}, {g}, {b})", inline=True)
        embed.add_field(name="Décimal", value=str(color_int), inline=True)
        
        # Créer une "image" de couleur avec des émojis
        color_display = "⬛" * 10  # Placeholder visuel
        embed.add_field(name="Aperçu", value=color_display, inline=False)
        
        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(AdvancedCommands(bot))