import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import logging
from datetime import datetime, timedelta

class ModerationCommands(commands.Cog):
    """Moderation commands for server management"""
    
    def __init__(self, bot):
        self.bot = bot
        self.logger = logging.getLogger(__name__)
    
    def has_mod_permissions():
        """Check if user has moderation permissions"""
        async def predicate(interaction: discord.Interaction):
            if not interaction.guild or not isinstance(interaction.user, discord.Member):
                return False
            return (interaction.user.guild_permissions.kick_members or 
                   interaction.user.guild_permissions.ban_members or
                   interaction.user.guild_permissions.manage_messages)
        return app_commands.check(predicate)
    
    @app_commands.command(name="expulser", description="Expulser un membre du serveur")
    @app_commands.describe(member="Le membre à expulser", reason="Raison de l'expulsion")
    @has_mod_permissions()
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: str = "Aucune raison fournie"):
        """Expulser un membre du serveur"""
        if member == interaction.user:
            await interaction.response.send_message("❌ Vous ne pouvez pas vous expulser vous-même !", ephemeral=True)
            return
        
        if member.top_role >= interaction.user.top_role:
            await interaction.response.send_message("❌ Vous ne pouvez pas expulser quelqu'un avec un rôle supérieur ou égal !", ephemeral=True)
            return
        
        try:
            # Send DM to the user before kicking
            try:
                guild_name = interaction.guild.name if interaction.guild else "Serveur Inconnu"
                embed = discord.Embed(
                    title="Vous avez été expulsé",
                    description=f"Vous avez été expulsé de **{guild_name}**",
                    color=discord.Color.orange(),
                    timestamp=datetime.utcnow()
                )
                embed.add_field(name="Raison", value=reason, inline=False)
                embed.add_field(name="Modérateur", value=interaction.user.mention, inline=False)
                await member.send(embed=embed)
            except discord.Forbidden:
                pass  # User has DMs disabled
            
            # Kick the member
            await member.kick(reason=f"Kicked by {interaction.user} - {reason}")
            
            # Send confirmation
            embed = discord.Embed(
                title="Membre Expulsé",
                description=f"**{member}** a été expulsé du serveur",
                color=discord.Color.orange(),
                timestamp=datetime.utcnow()
            )
            embed.add_field(name="Raison", value=reason, inline=False)
            embed.add_field(name="Modérateur", value=interaction.user.mention, inline=False)
            
            await interaction.response.send_message(embed=embed)
            self.logger.info(f"{interaction.user} kicked {member} - Reason: {reason}")
            
        except discord.Forbidden:
            await interaction.response.send_message("❌ Je n'ai pas la permission d'expulser ce membre !", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message("❌ Une erreur s'est produite lors de l'expulsion du membre !", ephemeral=True)
            self.logger.error(f"Error kicking member: {e}")
    
    @app_commands.command(name="ban", description="Ban a member from the server")
    @app_commands.describe(member="The member to ban", reason="Reason for banning", delete_days="Days of messages to delete (0-7)")
    @has_mod_permissions()
    async def ban(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided", delete_days: int = 0):
        """Ban a member from the server"""
        if member == interaction.user:
            await interaction.response.send_message("❌ You cannot ban yourself!", ephemeral=True)
            return
        
        if member.top_role >= interaction.user.top_role:
            await interaction.response.send_message("❌ You cannot ban someone with a higher or equal role!", ephemeral=True)
            return
        
        if delete_days < 0 or delete_days > 7:
            await interaction.response.send_message("❌ Delete days must be between 0 and 7!", ephemeral=True)
            return
        
        try:
            # Send DM to the user before banning
            try:
                embed = discord.Embed(
                    title="You have been banned",
                    description=f"You were banned from **{interaction.guild.name if interaction.guild else 'Unknown Server'}**",
                    color=discord.Color.red(),
                    timestamp=datetime.utcnow()
                )
                embed.add_field(name="Reason", value=reason, inline=False)
                embed.add_field(name="Moderator", value=interaction.user.mention, inline=False)
                await member.send(embed=embed)
            except discord.Forbidden:
                pass  # User has DMs disabled
            
            # Ban the member
            await member.ban(reason=f"Banned by {interaction.user} - {reason}", delete_message_days=delete_days)
            
            # Send confirmation
            embed = discord.Embed(
                title="Member Banned",
                description=f"**{member}** has been banned from the server",
                color=discord.Color.red(),
                timestamp=datetime.utcnow()
            )
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.add_field(name="Moderator", value=interaction.user.mention, inline=False)
            if delete_days > 0:
                embed.add_field(name="Messages Deleted", value=f"{delete_days} day(s)", inline=False)
            
            await interaction.response.send_message(embed=embed)
            self.logger.info(f"{interaction.user} banned {member} - Reason: {reason}")
            
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to ban this member!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message("❌ An error occurred while banning the member!", ephemeral=True)
            self.logger.error(f"Error banning member: {e}")
    
    @app_commands.command(name="unban", description="Unban a user from the server")
    @app_commands.describe(user_id="The ID of the user to unban", reason="Reason for unbanning")
    @has_mod_permissions()
    async def unban(self, interaction: discord.Interaction, user_id: str, reason: str = "No reason provided"):
        """Unban a user from the server"""
        try:
            user_id = int(user_id)
        except ValueError:
            await interaction.response.send_message("❌ Invalid user ID format!", ephemeral=True)
            return
        
        try:
            # Get the banned user
            banned_users = [entry async for entry in interaction.guild.bans()]
            banned_user = None
            
            for ban_entry in banned_users:
                if ban_entry.user.id == user_id:
                    banned_user = ban_entry.user
                    break
            
            if not banned_user:
                await interaction.response.send_message("❌ User is not banned or ID not found!", ephemeral=True)
                return
            
            # Unban the user
            await interaction.guild.unban(banned_user, reason=f"Unbanned by {interaction.user} - {reason}")
            
            # Send confirmation
            embed = discord.Embed(
                title="User Unbanned",
                description=f"**{banned_user}** has been unbanned from the server",
                color=discord.Color.green(),
                timestamp=datetime.utcnow()
            )
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.add_field(name="Moderator", value=interaction.user.mention, inline=False)
            
            await interaction.response.send_message(embed=embed)
            self.logger.info(f"{interaction.user} unbanned {banned_user} - Reason: {reason}")
            
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to unban users!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message("❌ An error occurred while unbanning the user!", ephemeral=True)
            self.logger.error(f"Error unbanning user: {e}")
    
    @app_commands.command(name="timeout", description="Timeout a member")
    @app_commands.describe(member="The member to timeout", duration="Duration in minutes", reason="Reason for timeout")
    @has_mod_permissions()
    async def timeout(self, interaction: discord.Interaction, member: discord.Member, duration: int, reason: str = "No reason provided"):
        """Timeout a member for a specified duration"""
        if member == interaction.user:
            await interaction.response.send_message("❌ You cannot timeout yourself!", ephemeral=True)
            return
        
        if member.top_role >= interaction.user.top_role:
            await interaction.response.send_message("❌ You cannot timeout someone with a higher or equal role!", ephemeral=True)
            return
        
        if duration < 1 or duration > 40320:  # Max timeout is 28 days
            await interaction.response.send_message("❌ Duration must be between 1 minute and 28 days (40320 minutes)!", ephemeral=True)
            return
        
        try:
            # Calculate timeout duration
            timeout_until = datetime.utcnow() + timedelta(minutes=duration)
            
            # Apply timeout
            await member.timeout(timeout_until, reason=f"Timed out by {interaction.user} - {reason}")
            
            # Send confirmation
            embed = discord.Embed(
                title="Member Timed Out",
                description=f"**{member}** has been timed out",
                color=discord.Color.orange(),
                timestamp=datetime.utcnow()
            )
            embed.add_field(name="Duration", value=f"{duration} minute(s)", inline=False)
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.add_field(name="Moderator", value=interaction.user.mention, inline=False)
            embed.add_field(name="Timeout ends", value=f"<t:{int(timeout_until.timestamp())}:R>", inline=False)
            
            await interaction.response.send_message(embed=embed)
            self.logger.info(f"{interaction.user} timed out {member} for {duration} minutes - Reason: {reason}")
            
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to timeout this member!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message("❌ An error occurred while timing out the member!", ephemeral=True)
            self.logger.error(f"Error timing out member: {e}")
    
    @app_commands.command(name="clear", description="Delete a number of messages")
    @app_commands.describe(amount="Number of messages to delete (1-100)")
    @has_mod_permissions()
    async def clear(self, interaction: discord.Interaction, amount: int):
        """Delete a specified number of messages"""
        if amount < 1 or amount > 100:
            await interaction.response.send_message("❌ Amount must be between 1 and 100!", ephemeral=True)
            return
        
        try:
            # Delete messages
            deleted = await interaction.channel.purge(limit=amount)
            
            # Send confirmation (will be auto-deleted after 5 seconds)
            embed = discord.Embed(
                title="Messages Cleared",
                description=f"Successfully deleted {len(deleted)} message(s)",
                color=discord.Color.green(),
                timestamp=datetime.utcnow()
            )
            embed.add_field(name="Moderator", value=interaction.user.mention, inline=False)
            
            await interaction.response.send_message(embed=embed, delete_after=5)
            self.logger.info(f"{interaction.user} cleared {len(deleted)} messages in #{interaction.channel.name}")
            
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to delete messages!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message("❌ An error occurred while deleting messages!", ephemeral=True)
            self.logger.error(f"Error clearing messages: {e}")
