import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime
import platform
import psutil
import os

class InfoCommands(commands.Cog):
    """Information and utility commands"""
    
    def __init__(self, bot):
        self.bot = bot
        self.config = bot.config
    
    @app_commands.command(name="aide", description="Afficher toutes les commandes et fonctionnalités disponibles")
    async def help(self, interaction: discord.Interaction):
        """Affiche les informations d'aide"""
        embed = discord.Embed(
            title=f"🤖 {self.config.get('bot_name', 'Bot Communauté')} - Aide",
            description="Voici toutes les commandes et fonctionnalités disponibles :",
            color=int(self.config.get('embed_color', '0x7289DA').replace('0x', ''), 16),
            timestamp=datetime.utcnow()
        )
        
        # Commandes de Modération
        mod_commands = [
            "`/expulser` - Expulser un membre du serveur",
            "`/bannir` - Bannir un membre du serveur",
            "`/debannir` - Débannir un utilisateur du serveur",
            "`/timeout` - Mettre un membre en timeout",
            "`/nettoyer` - Supprimer plusieurs messages"
        ]
        embed.add_field(name="🛡️ Commandes de Modération", value="\n".join(mod_commands), inline=False)
        
        # Commandes Amusantes
        fun_commands = [
            "`/blague` - Obtenir une blague aléatoire",
            "`/fait` - Obtenir un fait amusant aléatoire",
            "`/de` - Lancer des dés",
            "`/piece` - Lancer une pièce",
            "`/8ball` - Demander à la boule magique",
            "`/choisir` - Choisir parmi des options",
            "`/pfc` - Jouer à Pierre-Feuille-Ciseaux"
        ]
        embed.add_field(name="🎉 Commandes Amusantes", value="\n".join(fun_commands), inline=False)
        
        # Commandes d'Information
        info_commands = [
            "`/aide` - Afficher ce message d'aide",
            "`/infoserveur` - Afficher les informations du serveur",
            "`/infoutilisateur` - Afficher les informations d'un utilisateur",
            "`/infobot` - Afficher les informations du bot",
            "`/ping` - Vérifier la latence du bot"
        ]
        embed.add_field(name="ℹ️ Commandes d'Information", value="\n".join(info_commands), inline=False)
        
        embed.add_field(name="🔧 Fonctionnalités", value="• Messages de bienvenue pour nouveaux membres\n• Gestion automatique des rôles\n• Système de logs complet", inline=False)
        embed.set_footer(text="Bot créé pour la gestion de communauté", icon_url=self.bot.user.avatar.url if self.bot.user.avatar else None)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="serverinfo", description="Display information about the server")
    async def serverinfo(self, interaction: discord.Interaction):
        """Display server information"""
        guild = interaction.guild
        
        # Count members by status
        online = sum(1 for member in guild.members if member.status == discord.Status.online)
        idle = sum(1 for member in guild.members if member.status == discord.Status.idle)
        dnd = sum(1 for member in guild.members if member.status == discord.Status.dnd)
        offline = sum(1 for member in guild.members if member.status == discord.Status.offline)
        
        # Count channels
        text_channels = len(guild.text_channels)
        voice_channels = len(guild.voice_channels)
        categories = len(guild.categories)
        
        embed = discord.Embed(
            title=f"📊 {guild.name} - Server Information",
            color=int(self.config.get('embed_color', '0x7289DA').replace('0x', ''), 16),
            timestamp=datetime.utcnow()
        )
        
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        
        # Basic info
        embed.add_field(name="📝 Server Name", value=guild.name, inline=True)
        embed.add_field(name="🆔 Server ID", value=guild.id, inline=True)
        embed.add_field(name="👑 Owner", value=guild.owner.mention if guild.owner else "Unknown", inline=True)
        
        # Member info
        embed.add_field(name="👥 Total Members", value=guild.member_count, inline=True)
        embed.add_field(name="🟢 Online", value=online, inline=True)
        embed.add_field(name="🟡 Idle", value=idle, inline=True)
        embed.add_field(name="🔴 DND", value=dnd, inline=True)
        embed.add_field(name="⚫ Offline", value=offline, inline=True)
        embed.add_field(name="🤖 Bots", value=sum(1 for member in guild.members if member.bot), inline=True)
        
        # Channel info
        embed.add_field(name="💬 Text Channels", value=text_channels, inline=True)
        embed.add_field(name="🔊 Voice Channels", value=voice_channels, inline=True)
        embed.add_field(name="📁 Categories", value=categories, inline=True)
        
        # Additional info
        embed.add_field(name="🎭 Roles", value=len(guild.roles), inline=True)
        embed.add_field(name="😀 Emojis", value=len(guild.emojis), inline=True)
        embed.add_field(name="🚀 Boosts", value=guild.premium_subscription_count, inline=True)
        
        # Server creation date
        created_at = guild.created_at
        embed.add_field(name="📅 Created", value=f"<t:{int(created_at.timestamp())}:F>", inline=False)
        
        embed.set_footer(text=f"Requested by {interaction.user.display_name}", icon_url=interaction.user.avatar.url if interaction.user.avatar else None)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="userinfo", description="Display information about a user")
    @app_commands.describe(user="The user to get information about (optional)")
    async def userinfo(self, interaction: discord.Interaction, user: discord.Member = None):
        """Display user information"""
        if user is None:
            user = interaction.user
        
        embed = discord.Embed(
            title=f"👤 {user.display_name} - User Information",
            color=user.color if user.color != discord.Color.default() else int(self.config.get('embed_color', '0x7289DA').replace('0x', ''), 16),
            timestamp=datetime.utcnow()
        )
        
        if user.avatar:
            embed.set_thumbnail(url=user.avatar.url)
        
        # Basic info
        embed.add_field(name="👤 Username", value=f"{user.name}#{user.discriminator}", inline=True)
        embed.add_field(name="🏷️ Display Name", value=user.display_name, inline=True)
        embed.add_field(name="🆔 User ID", value=user.id, inline=True)
        
        # Status and activity
        status_emoji = {
            discord.Status.online: "🟢 Online",
            discord.Status.idle: "🟡 Idle",
            discord.Status.dnd: "🔴 Do Not Disturb",
            discord.Status.offline: "⚫ Offline"
        }
        embed.add_field(name="📶 Status", value=status_emoji.get(user.status, "❓ Unknown"), inline=True)
        
        # Account creation and join date
        embed.add_field(name="📅 Account Created", value=f"<t:{int(user.created_at.timestamp())}:F>", inline=False)
        embed.add_field(name="📅 Joined Server", value=f"<t:{int(user.joined_at.timestamp())}:F>", inline=False)
        
        # Roles
        roles = [role.mention for role in user.roles[1:]]  # Exclude @everyone
        if roles:
            roles_text = ", ".join(roles) if len(", ".join(roles)) <= 1024 else f"{len(roles)} roles"
            embed.add_field(name="🎭 Roles", value=roles_text, inline=False)
        
        # Permissions
        if user.guild_permissions.administrator:
            embed.add_field(name="🔑 Permissions", value="👑 Administrator", inline=True)
        elif user.guild_permissions.manage_guild:
            embed.add_field(name="🔑 Permissions", value="🛡️ Server Manager", inline=True)
        elif user.guild_permissions.kick_members or user.guild_permissions.ban_members:
            embed.add_field(name="🔑 Permissions", value="⚖️ Moderator", inline=True)
        
        # Bot check
        if user.bot:
            embed.add_field(name="🤖 Bot", value="Yes", inline=True)
        
        embed.set_footer(text=f"Requested by {interaction.user.display_name}", icon_url=interaction.user.avatar.url if interaction.user.avatar else None)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="botinfo", description="Display information about the bot")
    async def botinfo(self, interaction: discord.Interaction):
        """Display bot information"""
        # Get system info
        python_version = platform.python_version()
        discord_version = discord.__version__
        
        # Get process info
        process = psutil.Process(os.getpid())
        memory_usage = process.memory_info().rss / 1024 / 1024  # Convert to MB
        cpu_usage = process.cpu_percent()
        
        embed = discord.Embed(
            title=f"🤖 {self.config.get('bot_name', 'Community Bot')} - Bot Information",
            description=self.config.get('description', 'A comprehensive Discord bot for community management'),
            color=int(self.config.get('embed_color', '0x7289DA').replace('0x', ''), 16),
            timestamp=datetime.utcnow()
        )
        
        if self.bot.user.avatar:
            embed.set_thumbnail(url=self.bot.user.avatar.url)
        
        # Bot stats
        embed.add_field(name="🏠 Servers", value=len(self.bot.guilds), inline=True)
        embed.add_field(name="👥 Users", value=len(self.bot.users), inline=True)
        embed.add_field(name="💬 Channels", value=len(list(self.bot.get_all_channels())), inline=True)
        
        # Technical info
        embed.add_field(name="🐍 Python", value=python_version, inline=True)
        embed.add_field(name="📚 Discord.py", value=discord_version, inline=True)
        embed.add_field(name="🏓 Latency", value=f"{round(self.bot.latency * 1000)}ms", inline=True)
        
        # System stats
        embed.add_field(name="💾 Memory Usage", value=f"{memory_usage:.1f} MB", inline=True)
        embed.add_field(name="🖥️ CPU Usage", value=f"{cpu_usage:.1f}%", inline=True)
        embed.add_field(name="⏰ Uptime", value=f"<t:{int(self.bot.user.created_at.timestamp())}:R>", inline=True)
        
        # Links and info
        embed.add_field(name="📅 Bot Created", value=f"<t:{int(self.bot.user.created_at.timestamp())}:F>", inline=False)
        embed.add_field(name="✨ Features", value="Moderation • Fun Commands • Member Management • Welcome System", inline=False)
        
        embed.set_footer(text=f"Requested by {interaction.user.display_name}", icon_url=interaction.user.avatar.url if interaction.user.avatar else None)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="ping", description="Check the bot's latency")
    async def ping(self, interaction: discord.Interaction):
        """Check bot latency"""
        latency = round(self.bot.latency * 1000)
        
        # Determine latency quality
        if latency < 100:
            color = discord.Color.green()
            quality = "Excellent"
        elif latency < 200:
            color = discord.Color.yellow()
            quality = "Good"
        elif latency < 300:
            color = discord.Color.orange()
            quality = "Fair"
        else:
            color = discord.Color.red()
            quality = "Poor"
        
        embed = discord.Embed(
            title="🏓 Pong!",
            description=f"**{latency}ms** - {quality}",
            color=color,
            timestamp=datetime.utcnow()
        )
        embed.set_footer(text=f"Requested by {interaction.user.display_name}", icon_url=interaction.user.avatar.url if interaction.user.avatar else None)
        
        await interaction.response.send_message(embed=embed)
