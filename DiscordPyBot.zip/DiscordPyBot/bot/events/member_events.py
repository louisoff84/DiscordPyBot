import discord
from discord.ext import commands
import random
import logging
from datetime import datetime

class MemberEvents(commands.Cog):
    """Handle member-related events like joins and leaves"""
    
    def __init__(self, bot):
        self.bot = bot
        self.config = bot.config
        self.logger = logging.getLogger(__name__)
    
    @commands.Cog.listener()
    async def on_member_join(self, member):
        """Handle when a member joins the server"""
        self.logger.info(f"Member joined: {member} ({member.id}) in {member.guild.name}")
        
        # Send welcome message
        await self.send_welcome_message(member)
        
        # Add default role if configured
        await self.add_default_role(member)
        
        # Log to log channel if configured
        await self.log_member_join(member)
    
    @commands.Cog.listener()
    async def on_member_remove(self, member):
        """Handle when a member leaves the server"""
        self.logger.info(f"Member left: {member} ({member.id}) from {member.guild.name}")
        
        # Log to log channel if configured
        await self.log_member_leave(member)
    
    async def send_welcome_message(self, member):
        """Send a welcome message to the welcome channel"""
        welcome_channel_id = self.config.get('welcome_channel')
        if not welcome_channel_id:
            return
        
        welcome_channel = member.guild.get_channel(welcome_channel_id)
        if not welcome_channel:
            self.logger.warning(f"Welcome channel {welcome_channel_id} not found in {member.guild.name}")
            return
        
        # Get random welcome message
        welcome_messages = self.config.get('welcome_messages', [
            "Welcome to the server, {user}! 🎉"
        ])
        welcome_text = random.choice(welcome_messages).format(user=member.mention)
        
        # Create welcome embed
        embed = discord.Embed(
            title="Welcome! 👋",
            description=welcome_text,
            color=discord.Color.green(),
            timestamp=datetime.utcnow()
        )
        
        if member.avatar:
            embed.set_thumbnail(url=member.avatar.url)
        
        embed.add_field(
            name="Member Count",
            value=f"You are member #{member.guild.member_count}!",
            inline=False
        )
        
        embed.add_field(
            name="Getting Started",
            value="• Read the rules\n• Introduce yourself\n• Explore the channels\n• Have fun!",
            inline=False
        )
        
        embed.set_footer(
            text=f"Joined {member.guild.name}",
            icon_url=member.guild.icon.url if member.guild.icon else None
        )
        
        try:
            await welcome_channel.send(embed=embed)
            self.logger.info(f"Welcome message sent for {member} in {member.guild.name}")
        except discord.Forbidden:
            self.logger.error(f"No permission to send welcome message in {welcome_channel.name}")
        except Exception as e:
            self.logger.error(f"Error sending welcome message: {e}")
    
    async def add_default_role(self, member):
        """Add a default role to new members if configured"""
        # This would be implemented based on server configuration
        # For now, we'll skip this as it requires specific role setup
        pass
    
    async def log_member_join(self, member):
        """Log member join to the log channel"""
        log_channel_id = self.config.get('log_channel')
        if not log_channel_id:
            return
        
        log_channel = member.guild.get_channel(log_channel_id)
        if not log_channel:
            return
        
        embed = discord.Embed(
            title="📥 Member Joined",
            color=discord.Color.green(),
            timestamp=datetime.utcnow()
        )
        
        embed.add_field(name="Member", value=f"{member} ({member.mention})", inline=False)
        embed.add_field(name="Account Created", value=f"<t:{int(member.created_at.timestamp())}:R>", inline=True)
        embed.add_field(name="Member Count", value=member.guild.member_count, inline=True)
        
        if member.avatar:
            embed.set_thumbnail(url=member.avatar.url)
        
        embed.set_footer(text=f"ID: {member.id}")
        
        try:
            await log_channel.send(embed=embed)
        except discord.Forbidden:
            self.logger.error(f"No permission to send to log channel {log_channel.name}")
        except Exception as e:
            self.logger.error(f"Error logging member join: {e}")
    
    async def log_member_leave(self, member):
        """Log member leave to the log channel"""
        log_channel_id = self.config.get('log_channel')
        if not log_channel_id:
            return
        
        log_channel = member.guild.get_channel(log_channel_id)
        if not log_channel:
            return
        
        embed = discord.Embed(
            title="📤 Member Left",
            color=discord.Color.red(),
            timestamp=datetime.utcnow()
        )
        
        embed.add_field(name="Member", value=f"{member}", inline=False)
        embed.add_field(name="Joined", value=f"<t:{int(member.joined_at.timestamp())}:R>" if member.joined_at else "Unknown", inline=True)
        embed.add_field(name="Member Count", value=member.guild.member_count, inline=True)
        
        if member.avatar:
            embed.set_thumbnail(url=member.avatar.url)
        
        embed.set_footer(text=f"ID: {member.id}")
        
        try:
            await log_channel.send(embed=embed)
        except discord.Forbidden:
            self.logger.error(f"No permission to send to log channel {log_channel.name}")
        except Exception as e:
            self.logger.error(f"Error logging member leave: {e}")
    
    @commands.Cog.listener()
    async def on_guild_join(self, guild):
        """Handle when the bot joins a new server"""
        self.logger.info(f"Bot joined new guild: {guild.name} ({guild.id})")
        
        # Try to send a setup message to the first available text channel
        for channel in guild.text_channels:
            if channel.permissions_for(guild.me).send_messages:
                embed = discord.Embed(
                    title="👋 Thanks for adding me!",
                    description="I'm a community management bot with moderation, fun commands, and member management features.",
                    color=discord.Color.blue(),
                    timestamp=datetime.utcnow()
                )
                
                embed.add_field(
                    name="🚀 Getting Started",
                    value="• Use `/help` to see all available commands\n• Configure welcome and log channels in config.json\n• Set up moderation roles as needed",
                    inline=False
                )
                
                embed.add_field(
                    name="✨ Features",
                    value="• Slash commands for easy use\n• Moderation tools (kick, ban, timeout, etc.)\n• Fun commands (jokes, facts, games)\n• Welcome messages for new members\n• Server information commands",
                    inline=False
                )
                
                embed.set_footer(text="Use /help for a full list of commands")
                
                try:
                    await channel.send(embed=embed)
                    break
                except discord.Forbidden:
                    continue
    
    @commands.Cog.listener()
    async def on_guild_remove(self, guild):
        """Handle when the bot is removed from a server"""
        self.logger.info(f"Bot removed from guild: {guild.name} ({guild.id})")
