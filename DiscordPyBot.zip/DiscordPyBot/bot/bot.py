import discord
from discord.ext import commands
import json
import logging
import os
from pathlib import Path

from bot.commands.moderation import ModerationCommands
from bot.commands.fun import FunCommands
from bot.commands.info import InfoCommands
from bot.commands.advanced import AdvancedCommands
from bot.events.member_events import MemberEvents

class CommunityBot(commands.Bot):
    """Main bot class that handles initialization and setup"""
    
    def __init__(self):
        # Load configuration
        self.config = self.load_config()
        
        # Initialize bot with minimal intents to avoid privileged intent errors
        intents = discord.Intents.default()
        intents.message_content = False  # This is actually privileged too
        intents.members = False  # Explicitly disable privileged intent
        intents.presences = False  # Explicitly disable privileged intent
        intents.guilds = True
        intents.guild_messages = True
        
        super().__init__(
            command_prefix=self.config.get('prefix', '!'),
            intents=intents,
            description=self.config.get('description', 'Community Discord Bot'),
            help_command=None  # We'll create a custom help command
        )
        
        self.logger = logging.getLogger(__name__)
        
    def load_config(self):
        """Load configuration from config.json"""
        config_path = Path(__file__).parent.parent / 'config.json'
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            self.logger.error("config.json not found! Using default configuration.")
            return self.get_default_config()
        except json.JSONDecodeError:
            self.logger.error("Invalid JSON in config.json! Using default configuration.")
            return self.get_default_config()
    
    def get_default_config(self):
        """Return default configuration if config.json is not available"""
        return {
            "bot_name": "Community Bot",
            "description": "A comprehensive Discord bot for community management",
            "prefix": "!",
            "embed_color": "0x7289DA"
        }
    
    async def setup_hook(self):
        """Called when the bot is starting up"""
        # Add cogs (command groups)
        await self.add_cog(ModerationCommands(self))
        await self.add_cog(FunCommands(self))
        await self.add_cog(InfoCommands(self))
        await self.add_cog(AdvancedCommands(self))
        await self.add_cog(MemberEvents(self))
        
        # Sync slash commands
        try:
            synced = await self.tree.sync()
            self.logger.info(f"Synced {len(synced)} command(s)")
        except Exception as e:
            self.logger.error(f"Failed to sync commands: {e}")
    
    async def on_ready(self):
        """Called when the bot is ready"""
        self.logger.info(f'{self.user} has connected to Discord!')
        self.logger.info(f'Bot is in {len(self.guilds)} guild(s)')
        
        # Set bot status
        activity = discord.Activity(
            type=discord.ActivityType.watching,
            name="the community | /help"
        )
        await self.change_presence(activity=activity)
    
    async def on_command_error(self, ctx, error):
        """Global error handler for commands"""
        if isinstance(error, commands.CommandNotFound):
            return  # Ignore unknown commands
        
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ You don't have permission to use this command!")
            return
        
        if isinstance(error, commands.BotMissingPermissions):
            await ctx.send("❌ I don't have the necessary permissions to execute this command!")
            return
        
        if isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(f"❌ Missing required argument: `{error.param}`")
            return
        
        # Log unexpected errors
        self.logger.error(f"Unexpected error in command {ctx.command}: {error}")
        await ctx.send("❌ An unexpected error occurred. Please try again later.")
