import discord
from datetime import datetime, timedelta
import re
import asyncio

def create_embed(title: str, description: str = None, color: discord.Color = None, timestamp: bool = True):
    """Create a standardized embed"""
    embed = discord.Embed(
        title=title,
        description=description,
        color=color or discord.Color.blue()
    )
    
    if timestamp:
        embed.timestamp = datetime.utcnow()
    
    return embed

def parse_time(time_str: str) -> timedelta:
    """Parse time string into timedelta object"""
    time_regex = re.compile(r'(\d+)([smhdw])')
    matches = time_regex.findall(time_str.lower())
    
    if not matches:
        raise ValueError("Invalid time format")
    
    total_seconds = 0
    for amount, unit in matches:
        amount = int(amount)
        if unit == 's':
            total_seconds += amount
        elif unit == 'm':
            total_seconds += amount * 60
        elif unit == 'h':
            total_seconds += amount * 3600
        elif unit == 'd':
            total_seconds += amount * 86400
        elif unit == 'w':
            total_seconds += amount * 604800
    
    return timedelta(seconds=total_seconds)

def format_time(seconds: int) -> str:
    """Format seconds into a readable time string"""
    if seconds < 60:
        return f"{seconds} second{'s' if seconds != 1 else ''}"
    elif seconds < 3600:
        minutes = seconds // 60
        return f"{minutes} minute{'s' if minutes != 1 else ''}"
    elif seconds < 86400:
        hours = seconds // 3600
        return f"{hours} hour{'s' if hours != 1 else ''}"
    else:
        days = seconds // 86400
        return f"{days} day{'s' if days != 1 else ''}"

async def get_or_fetch_user(bot, user_id: int):
    """Get user from cache or fetch from Discord API"""
    user = bot.get_user(user_id)
    if user is None:
        try:
            user = await bot.fetch_user(user_id)
        except discord.NotFound:
            return None
    return user

def truncate_text(text: str, max_length: int = 1024) -> str:
    """Truncate text to fit Discord embed field limits"""
    if len(text) <= max_length:
        return text
    return text[:max_length - 3] + "..."

def has_permissions(member: discord.Member, **perms) -> bool:
    """Check if member has required permissions"""
    return all(getattr(member.guild_permissions, perm, False) for perm in perms)

def is_moderator(member: discord.Member) -> bool:
    """Check if member has moderation permissions"""
    return has_permissions(member, kick_members=True) or has_permissions(member, ban_members=True) or has_permissions(member, manage_messages=True)

def is_admin(member: discord.Member) -> bool:
    """Check if member has admin permissions"""
    return has_permissions(member, administrator=True) or member.guild_permissions.manage_guild

async def safe_send(destination, *args, **kwargs):
    """Safely send a message, handling common errors"""
    try:
        return await destination.send(*args, **kwargs)
    except discord.Forbidden:
        # No permission to send messages
        return None
    except discord.HTTPException:
        # Message too long or other HTTP error
        return None

def get_member_status_emoji(status: discord.Status) -> str:
    """Get emoji for member status"""
    status_emojis = {
        discord.Status.online: "🟢",
        discord.Status.idle: "🟡",
        discord.Status.dnd: "🔴",
        discord.Status.offline: "⚫"
    }
    return status_emojis.get(status, "❓")

def format_member_list(members: list, max_length: int = 1024) -> str:
    """Format a list of members for display"""
    if not members:
        return "None"
    
    member_strings = [str(member) for member in members]
    result = ", ".join(member_strings)
    
    if len(result) > max_length:
        # Truncate and add count
        truncated = []
        current_length = 0
        
        for member_str in member_strings:
            if current_length + len(member_str) + 2 > max_length - 20:  # Leave space for "... and X more"
                remaining = len(member_strings) - len(truncated)
                truncated.append(f"... and {remaining} more")
                break
            truncated.append(member_str)
            current_length += len(member_str) + 2  # +2 for ", "
        
        result = ", ".join(truncated)
    
    return result
