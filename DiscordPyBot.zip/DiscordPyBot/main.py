#!/usr/bin/env python3
"""
Discord Community Bot
A comprehensive Discord bot with moderation, fun commands, and member management features.
"""

import asyncio
import logging
import os
import sys
from pathlib import Path

# Add the bot directory to the Python path
sys.path.append(str(Path(__file__).parent))

from bot.bot import CommunityBot

def setup_logging():
    """Setup logging configuration"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('bot.log'),
            logging.StreamHandler()
        ]
    )

async def main():
    """Main function to run the bot"""
    setup_logging()
    logger = logging.getLogger(__name__)
    
    # Get Discord token from environment variables
    token = os.getenv('DISCORD_TOKEN')
    if not token:
        logger.error("DISCORD_TOKEN environment variable not found!")
        logger.error("Please set your Discord bot token in the environment variables.")
        return
    
    # Create and run the bot
    bot = CommunityBot()
    
    try:
        logger.info("Starting Community Discord Bot...")
        await bot.start(token)
    except KeyboardInterrupt:
        logger.info("Bot shutdown requested by user")
    except Exception as e:
        logger.error(f"An error occurred: {e}")
    finally:
        await bot.close()

if __name__ == "__main__":
    asyncio.run(main())
